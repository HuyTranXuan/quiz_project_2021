Run the test by running the following line in the terminal window:
deno test --allow-all --unstable